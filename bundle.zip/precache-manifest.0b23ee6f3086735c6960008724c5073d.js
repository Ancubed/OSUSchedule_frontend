self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "494cddb0f74d158ab4d1ab7e3bea76a4",
    "url": "/osu_schedule/index.html"
  },
  {
    "revision": "fce5f4257493cbe04092",
    "url": "/osu_schedule/static/css/2.a6674286.chunk.css"
  },
  {
    "revision": "b0af95663c1f33a1ef56",
    "url": "/osu_schedule/static/css/main.4e7ff5e4.chunk.css"
  },
  {
    "revision": "fce5f4257493cbe04092",
    "url": "/osu_schedule/static/js/2.29c4113d.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/osu_schedule/static/js/2.29c4113d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "b0af95663c1f33a1ef56",
    "url": "/osu_schedule/static/js/main.a2dc31dd.chunk.js"
  },
  {
    "revision": "a324acab200e7c793f3a",
    "url": "/osu_schedule/static/js/runtime-main.5491f122.js"
  },
  {
    "revision": "31563ccd3b007592a504ce658a860597",
    "url": "/osu_schedule/static/media/logo.31563ccd.png"
  }
]);