self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5ed382035493d5e75457966a6d52583c",
    "url": "./index.html"
  },
  {
    "revision": "abf183533f7b8df35715",
    "url": "./static/css/2.a6674286.chunk.css"
  },
  {
    "revision": "f85b8f546541b89e067f",
    "url": "./static/css/main.4e7ff5e4.chunk.css"
  },
  {
    "revision": "abf183533f7b8df35715",
    "url": "./static/js/2.9add2b77.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "./static/js/2.9add2b77.chunk.js.LICENSE.txt"
  },
  {
    "revision": "f85b8f546541b89e067f",
    "url": "./static/js/main.e8a7a193.chunk.js"
  },
  {
    "revision": "6ecb3f858d3c977b1776",
    "url": "./static/js/runtime-main.6c52476b.js"
  },
  {
    "revision": "31563ccd3b007592a504ce658a860597",
    "url": "./static/media/logo.31563ccd.png"
  }
]);