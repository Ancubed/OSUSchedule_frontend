self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "96e020451b02f94640be285b57d0b83a",
    "url": "./index.html"
  },
  {
    "revision": "cd038e481b17b178861c",
    "url": "./static/css/2.a6674286.chunk.css"
  },
  {
    "revision": "d885fc9e8e3360cbf9b8",
    "url": "./static/css/main.4e7ff5e4.chunk.css"
  },
  {
    "revision": "cd038e481b17b178861c",
    "url": "./static/js/2.4e5b8c84.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "./static/js/2.4e5b8c84.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d885fc9e8e3360cbf9b8",
    "url": "./static/js/main.9e55be1e.chunk.js"
  },
  {
    "revision": "6ecb3f858d3c977b1776",
    "url": "./static/js/runtime-main.6c52476b.js"
  },
  {
    "revision": "31563ccd3b007592a504ce658a860597",
    "url": "./static/media/logo.31563ccd.png"
  }
]);