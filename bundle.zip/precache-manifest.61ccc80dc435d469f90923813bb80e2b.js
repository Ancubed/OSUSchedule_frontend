self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "53fcfb09fb08f693e7ff30f79c3be2cb",
    "url": "./index.html"
  },
  {
    "revision": "20a7d436d28742c1ac9e",
    "url": "./static/css/2.a6674286.chunk.css"
  },
  {
    "revision": "f079318eb3d3a9c37bce",
    "url": "./static/css/main.4e7ff5e4.chunk.css"
  },
  {
    "revision": "20a7d436d28742c1ac9e",
    "url": "./static/js/2.7ca8f866.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "./static/js/2.7ca8f866.chunk.js.LICENSE.txt"
  },
  {
    "revision": "f079318eb3d3a9c37bce",
    "url": "./static/js/main.0ab6fa60.chunk.js"
  },
  {
    "revision": "6ecb3f858d3c977b1776",
    "url": "./static/js/runtime-main.6c52476b.js"
  },
  {
    "revision": "31563ccd3b007592a504ce658a860597",
    "url": "./static/media/logo.31563ccd.png"
  }
]);